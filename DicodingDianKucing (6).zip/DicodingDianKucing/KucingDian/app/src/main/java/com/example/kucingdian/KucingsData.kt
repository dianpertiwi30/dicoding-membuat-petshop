package com.example.kucingdian

object KucingsData {
    private val kucingName = arrayOf("Kucing Ragdoll",
        "Kucing Russian Blue",
        "Kucing Persia",
        "Kucing Savana",
        "Kucing Bengal",
        "Kucing Himalaya",
        "Kucing British Shorthair",
        "Kucing Anggora",
    "Kucing Kampung",
    "Kucing Norwegian")

    private val kucingDetails = arrayOf(
        "Jenis kucing yang saat ini banyak dicari oleh penggemarnya adalah kucing ragdoll. Kucing yang mirip dengan boneka kain ini memiliki wajah imut dan pipi yang bulat.",
    "Kucing russian blue merupakan jenis kucing yang memiliki bulu pendek berwarna abu-abu kebiruan yang mengkilat. Jenis kucing ini juga dikenal cerdas, ramah, dan atraktif, sehingga cocok dijadikan hewan peliharaan di rumah.",
    "Selain anggora, jenis kucing yang terkenal di Indonesia berikutnya yaitu kucing persia. Salah satu ciri khas dari kucing ini adalah memiliki bulu yang panjang, lebat, berwajah bulat, dan hidung pesek.",
    "Kucing savana adalah jenis kucing yang memiliki bulu tebal, berbadan tinggi, lentur, dan ramping. Kucing hasil persilangan dari ras kucing Afrika dengan kucing Bengal ini menyerupai kucing liar yang buas dengan motif bulu bertotol.",
    "Kucing bengal atau Blacan merupakan jenis kucing keturunan ketiga dari hasil persilangan antara kucing american shorthair dengan kucing asian leopard. Kucing yang memiliki tubuh yang besar dan gagah ini, belum begitu banyak ditemukan, sehingga harganya cukup mahal",
    "Salah satu jenis kucing yang memiliki tubuh gemuk dan besar adalah kucing himalaya. Kucing himalaya sendiri merupakan hasil persilangan antara kucing persia dan kucing siam.",
    "Kucing British Shorthair adalah jenis kucing yang memiliki ukuran tubuh sedang sampai besar dengan berat badan sekitar 4–8 kg. Kucing ini mempunyai bentuk kepala bulat disertai dengan pipi yang berisi penuh.",
    "Salah satu jenis kucing yang populer dan digemari oleh semua kalangan adalah kucing anggora. Jenis kucing yang berasal dari Turki ini menjadi ras tertua di dunia.",
    "Tentu saja jenis kucing yang paling banyak dipelihara lainnya adalah kucing domestik atau kucing asli Indonesia. Kucing jawa ini memang sering kita jumpai diberbagai rumah dan di jalan karena memang disitulah kucing kampung berada.",
    "Bagi pecinta kucing, nama jenis satu ini pastinya tidak asing lagi. Kucing ini berasal dari Norwegia dan Skandaniva yang cukup banyak peminatnya di Indonesia.")

    private val kucingsImages = intArrayOf(
        R.drawable.kucing1,
        R.drawable.kucing2,
        R.drawable.kucing3,
        R.drawable.kucing4,
            R.drawable.kucing5,
        R.drawable.kucing6,
        R.drawable.kucing7,
        R.drawable.kucing8,
    R.drawable.kucing9,
    R.drawable.kucing10)

    val listData: ArrayList<Kucing>
        get() {
            val list = arrayListOf<Kucing>()
            for  (position  in  kucingName.indices)  {
                val  kucing =  Kucing()
                kucing.name  =  kucingName[position]
                kucing.detail  =  kucingDetails[position]
                kucing.photo  =  kucingsImages[position]
                list.add(kucing)
            }
            return  list
        }

}