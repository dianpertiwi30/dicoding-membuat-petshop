package com.example.kucingdian

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class HalamanDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_detail)

        val itemphoto1 = findViewById<ImageView>(R.id.gambar)
        val namamakanan1 = findViewById<TextView>(R.id.tv_kucing)
        val deskripsi1 = findViewById<TextView>(R.id.tv_detail)

        val itemphoto2 = intent.extras?.getInt("Gambar_Kucing")
        val namamakanan2 = intent.extras?.getString("Nama_Kucing")
        val deskripsi2 = intent.extras?.getString("Detail_Kucing")

        Glide
            .with(this)
            .load(itemphoto2)
            .centerCrop()
            .into(itemphoto1)

        namamakanan1.text = namamakanan2.toString()
        deskripsi1.text = deskripsi2.toString()

        val actionbar = supportActionBar
        actionbar!!.title = ""
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}