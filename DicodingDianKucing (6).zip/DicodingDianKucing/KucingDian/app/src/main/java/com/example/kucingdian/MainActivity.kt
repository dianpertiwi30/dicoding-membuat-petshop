package com.example.kucingdian

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), GridKucingAdapter.OnitemClickListener, ListKucingAdapter.OnItemClickListener {
    private  lateinit  var  rvKucings: RecyclerView
    private  var  list:  ArrayList<Kucing>  =  arrayListOf()
    private var title: String = "Mode List"


    override  fun  onCreate(savedInstanceState:  Bundle?)  {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setActionBarTitle(title)

        rvKucings  =  findViewById(R.id.rv_leptop)
        rvKucings.setHasFixedSize(true)

        list.addAll(KucingsData.listData)
        showRecyclerList()
    }

    private  fun  showRecyclerList()  {
        rvKucings.layoutManager  =  LinearLayoutManager(this)
        rvKucings.adapter = ListKucingAdapter(list, this)
        list.addAll(KucingsData.listData)

    }

    override  fun  onCreateOptionsMenu(menu: Menu):  Boolean  {
        menuInflater.inflate(R.menu.menu_main,  menu)
        return  super.onCreateOptionsMenu(menu)
    }

    override  fun  onOptionsItemSelected(item: MenuItem):  Boolean  {
        setMode(item.itemId)
        return  super.onOptionsItemSelected(item)
    }

    private  fun  setMode(selectedMode:  Int)  {
        when  (selectedMode)  {
            R.id.action_list  ->  {
                title  =  "Beranda"
                showRecyclerList()
            }

            R.id.action_grid  ->  {
                title  =  "Gambar Kucing"
                showRecyclerGrid()
            }

            R.id.action_cardview  ->  {
                title  =  "Item Kucing"
                showRecyclerCardView()
            }
            R.id.action_about  ->  {
                title  =  "About"
                val moveIntent = Intent(this@MainActivity, HalamanAbout::class.java)
                startActivity(moveIntent)
            }
        }
        setActionBarTitle(title)
    }

    private  fun  showRecyclerGrid()  {
        rvKucings.layoutManager  =  GridLayoutManager(this,  2)
        val  gridLeptopAdapter  =  GridKucingAdapter(list,this)
        rvKucings.adapter  =  gridLeptopAdapter

    }

    private  fun  showRecyclerCardView()  {
        rvKucings.layoutManager  =  LinearLayoutManager(this)
        val  cardViewKucingAdapter  =  CardViewKucingAdapter(list)
        rvKucings.adapter  =  cardViewKucingAdapter
    }

    private  fun  setActionBarTitle(title:  String)  {
        if  (supportActionBar  !=  null)  {
            (supportActionBar  as ActionBar).title  =  title
        }
    }

    private  fun  showSelectedMakanan(makanan:  Kucing)  { Toast.makeText(this,  "Kamu  memilih  "  +  makanan.name,
        Toast.LENGTH_SHORT).show()
    }

    override fun onItemClick(data: Kucing) {
        val intent = Intent(this, HalamanDetail::class.java)
        intent.putExtra("Nama_Kucing", data.name)
        intent.putExtra("Detail_Kucing", data.detail)
        intent.putExtra("Gambar_Kucing", data.photo)
        //intent.putExtra("Logo_Jurusan", data.photo.toString())
        startActivity(intent)
    }
}