package com.example.kucingdian

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class  GridKucingAdapter(val  listKucings:  ArrayList<Kucing>,  var ItemClickListener: MainActivity)
    : RecyclerView.Adapter<GridKucingAdapter.GridViewHolder>()  {


    override  fun  onCreateViewHolder(viewGroup: ViewGroup, i:  Int): GridViewHolder  {
        val  view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_grid_kucing, viewGroup,  false)
        return  GridViewHolder(view)
    }

    override  fun  onBindViewHolder(holder:  GridViewHolder,  position:  Int)  {
        Glide.with(holder.itemView.context)
            .load(listKucings[position].photo)
            .apply(RequestOptions().override(350,  550))
            .into(holder.imgPhoto)

        val kucing = listKucings[position]

        holder.bind(kucing, ItemClickListener)
    }

    override  fun  getItemCount():  Int  {
        return  listKucings.size
    }

    inner class GridViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        fun bind(kucing: Kucing, action: OnitemClickListener) {
            itemView.setOnClickListener {
                action.onItemClick(kucing)
            }
        }

var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
}

interface  OnitemClickListener  {
    fun  onItemClick(kucing: Kucing)
}

}