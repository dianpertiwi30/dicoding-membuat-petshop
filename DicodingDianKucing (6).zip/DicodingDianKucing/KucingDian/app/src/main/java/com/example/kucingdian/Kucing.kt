package com.example.kucingdian

data class Kucing (
    var name: String = "",
    var detail: String = "",
    var photo: Int = 0
)